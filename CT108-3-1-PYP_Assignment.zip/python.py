import os
from datetime import datetime

# Define the users file path
def get_files_path():
    return {
        "users": "users.txt",
        "ppe": "ppe.txt",
        "hospitals": "hospitals.txt",
        "suppliers": "suppliers.txt",
        "transactions": "transactions.txt",
    }

# Function to check if the file exists
def check_file_exists(file_path, filename):
    if not os.path.isfile(file_path):
        print(f"{filename} file not found. Please initialize data first.")
        return False
    return True

# Function to initialize the inventory
def initialize_inventory(items):
    file_path = get_files_path()["ppe"]
    if not check_file_exists(file_path, "PPE"):
        with open(file_path, "w") as file:
            for item in items:
                file.write(f"{item['Item Code']}|{item['Item Name']}|{item['Supplier Code']}|{item['Quantity']}\n")
        print("Inventory initialized with initial quantities.")
    else:
        print("Inventory file already exists. Skipping initialization.")

# Function to initialize suppliers
def initialize_suppliers(suppliers):
    file_path = get_files_path()["suppliers"]
    if not check_file_exists(file_path, "Suppliers"):
        with open(file_path, "w") as file:
            for supplier in suppliers:
                file.write(f"{supplier['Supplier Code']}|{supplier['Supplier Name']}\n")
        print("Suppliers initialized with initial data.")
    else:
        print("Suppliers file already exists. Skipping initialization.")

# Function to initialize hospitals
def initialize_hospitals(hospitals):
    file_path = get_files_path()["hospitals"]
    if not check_file_exists(file_path, "Hospitals"):
        with open(file_path, "w") as file:
            for hospital in hospitals:
                file.write(f"{hospital['Hospital Code']}|{hospital['Hospital Name']}\n")
        print("Hospitals initialized with initial data.")
    else:
        print("Hospitals file already exists. Skipping initialization.")

# Function to initialize transactions
def initialize_transactions():
    file_path = get_files_path()["transactions"]
    if not check_file_exists(file_path, "Transactions"):
        # If the file doesn't exist, create it
        with open(file_path, "w") as file:
            pass  # Create an empty file
        print("Transactions file initialized.")
    else:
        print("Transactions file already exists. Skipping initialization.")

# Function to initialize the data (inventory, suppliers, and hospitals)
def initialize_data():
    # Define the table of PPE items with initial quantities and supplier codes
    initial_ppe_items = [
        {"Item Code": "HC", "Item Name": "Head Cover", "Supplier Code": "S1", "Quantity": 100},
        {"Item Code": "FS", "Item Name": "Face Shield", "Supplier Code": "S2", "Quantity": 100},
        {"Item Code": "MS", "Item Name": "Mask", "Supplier Code": "S3", "Quantity": 100},
        {"Item Code": "GL", "Item Name": "Gloves", "Supplier Code": "S1", "Quantity": 100},
        {"Item Code": "GW", "Item Name": "Gown", "Supplier Code": "S2", "Quantity": 100},
        {"Item Code": "SC", "Item Name": "Shoe Covers", "Supplier Code": "S3", "Quantity": 100},
    ]
    # Define the initial list of suppliers
    initial_suppliers = [
        {"Supplier Code": "S1", "Supplier Name": "Supplier 1"},
        {"Supplier Code": "S2", "Supplier Name": "Supplier 2"},
        {"Supplier Code": "S3", "Supplier Name": "Supplier 3"},
    ]
    # Define the initial list of hospitals
    initial_hospitals = [
        {"Hospital Code": "H1", "Hospital Name": "Hospital 1"},
        {"Hospital Code": "H2", "Hospital Name": "Hospital 2"},
        {"Hospital Code": "H3", "Hospital Name": "Hospital 3"},
    ]
    
    print("\nInitializing data... \n")
    initialize_inventory(initial_ppe_items)
    initialize_suppliers(initial_suppliers)
    initialize_hospitals(initial_hospitals)
    initialize_transactions()
    print("Data initialization complete. \n")


# Function to check if a user ID already exists in the users file
def is_user_id_exists(user_id, users_file_path):
    with open(users_file_path, "r") as file:
        for line in file:
            user_data = line.strip().split("|")
            existing_user_id = user_data[0]
            if existing_user_id == user_id:
                return True, line
    return False, None

# Function to add a new user by an admin
def add_user():
    print("Add new user:")
    users_file_path = get_files_path()["users"]

    while True:
        user_id = input("Enter the user ID: ")
        user_exists, _ = is_user_id_exists(user_id, users_file_path)
        if user_exists:
            print(f"User with ID {user_id} already exists. Please choose a different user ID.")
        else:
            break

    user_name = input("Enter the user name: ")
    user_password = input("Enter the user password: ")

    while True:
        user_type = input("Enter the user type (admin or staff): ")
        if user_type.lower() not in ["admin", "staff"]:
            print("Invalid user type. User type must be 'admin' or 'staff'.")
        else:
            break

    new_user = {
        "User ID": user_id,
        "Name": user_name,
        "Password": user_password,
        "User Type": user_type.lower(),
    }

    with open(users_file_path, "a") as file:
        file.write(
            f"{new_user['User ID']}|{new_user['Name']}|{new_user['Password']}|{new_user['User Type']}\n"
        )

    print(f"User {user_name} ({user_type}) added successfully.")
    
# Function to modify user details by an admin
def modify_user():
    users_file_path = get_files_path()["users"]
    user_id_to_modify = input("Enter the user ID you want to modify: ")

    user_exists, user_line = is_user_id_exists(user_id_to_modify, users_file_path)
    if not user_exists:
        print(f"User with ID {user_id_to_modify} not found.")
        return     

    user_data = user_line.strip().split("|")

    print(f"\nUser ID: {user_data[0]}")
    print(f"Current Name: {user_data[1]}")
    updated_name = input("Enter the updated name (press Enter to keep current): ").strip()
    print(f"Current Password: {user_data[2]}")
    updated_password = input("Enter the updated password (press Enter to keep current): ").strip()
    print(f"Current User Type: {user_data[3]}")
    
    while True:
        updated_user_type = input("Enter the updated user type (admin or staff) (press Enter to keep current): ").strip()
        if updated_user_type.lower() not in ["admin", "staff", "\n", ""]:
            print("Invalid user type. User type must be 'admin' or 'staff'.")
        else:
            break

    updated_name = updated_name if updated_name else user_data[1]
    updated_password = updated_password if updated_password else user_data[2]
    updated_user_type = updated_user_type if updated_user_type else user_data[3]

    updated_user_data = []
    with open(users_file_path, "r") as file:
        for line in file:
            if line.strip().split("|")[0] == user_id_to_modify:
                updated_user_data.append(f"{user_id_to_modify}|{updated_name}|{updated_password}|{updated_user_type}\n")
            else:
                updated_user_data.append(line)

    with open(users_file_path, "w") as file:
        file.writelines(updated_user_data)

    print(f"User with ID {user_id_to_modify} updated successfully.")


# Function to search for a user by user ID
def search_user():
    users_file_path = get_files_path()["users"]
    user_id_to_search = input("Enter the user ID you want to search for: ")

    user_exists, user_line = is_user_id_exists(user_id_to_search, users_file_path)
    if not user_exists:
        print(f"User with ID {user_id_to_search} not found.")
        return     

    user_data = user_line.strip().split("|")

    print(f"User ID: {user_data[0]}")
    print(f"Name: {user_data[1]}")
    print(f"Password: {user_data[2]}")
    print(f"User Type: {user_data[3]} \n")

    choice = input("Do you want to display the transactions made by this user? (y/n): ")
    if choice.lower() == "y":
        display_user_transactions(user_id_to_search)
    else:
        print("User search complete.")

# Function to display transactions created by a user
def display_user_transactions(user_id):
    transactions_file_path = get_files_path()["transactions"]
    print(f"\nTransactions created by User ID {user_id}:")

    with open(transactions_file_path, "r") as file:
        transactions = [line.strip().split("|") for line in file]

    user_transactions = list(filter(lambda transaction: transaction[-1] == user_id, transactions))

    if not user_transactions:
        print(f"User ID {user_id} has not made any transactions.")
    else:
        print_transactions(user_transactions)

# Function to print transactions
def print_transactions(transactions):
    for transaction in transactions:
        date_time, item_code, quantity, transaction_type, code, created_by = transaction

        code_type = "Supplier" if transaction_type == "Received" else "Hospital"

        print(f"Date and Time: {date_time}")
        print(f"Item Code: {item_code}")
        print(f"Quantity: {quantity}")
        print(f"Transaction Type: {transaction_type}")
        print(f"Created By: {created_by}")
        print(f"{code_type} Code: {code}")
        print()

# Function to delete a user by an admin
def delete_user():
    users_file_path = get_files_path()["users"]
    user_id_to_delete = input("Enter the user ID you want to delete: ")

    user_exists, user_line = is_user_id_exists(user_id_to_delete, users_file_path)
    if not user_exists:
        print(f"User with ID {user_id_to_delete} not found.")
        return     

    user_data = user_line.strip().split("|")

    print(f"User ID: {user_data[0]}")
    print(f"Name: {user_data[1]}")
    print(f"Password: {user_data[2]}")
    print(f"User Type: {user_data[3]} \n")

    # Ask the admin to confirm the deletion
    choice = input("Are you sure you want to delete this user? (y/n): ")
    if choice.lower() == "y":
        updated_user_data = []
        with open(users_file_path, "r") as file:
            for line in file:
                if line.strip().split("|")[0] != user_id_to_delete:
                    updated_user_data.append(line)

        with open(users_file_path, "w") as file:
            file.writelines(updated_user_data)

        print(f"User with ID {user_id_to_delete} deleted successfully.")
    else:
        print("User deletion cancelled.")
    
    
# Function to add received items
def add_received_inventory(user_id):
    print("Add received items:")
    item_code = input("Enter the item code: ")
    
    if not code_exists(item_code, "item", get_files_path()["ppe"], "PPE"):
        return
    
    quantity = input("Enter the quantity: ")
    if not quantity.isdigit():
        print("Invalid quantity. Please try again.")
        return
    
    quantity = int(quantity)
    supplier_code = input("Enter the supplier code: ")
    if not code_exists(supplier_code, "supplier", get_files_path()["suppliers"], "Suppliers"):
        return
    
    if not check_item_supplier_code(item_code, supplier_code):
        return
    
    update_item_stock(item_code, quantity, "received")
    record_transaction(item_code, quantity, "received", supplier_code, user_id)
    print("Item receipt completed successfully.")
    
# Function to add distributed items
def add_distributed_inventory(user_id):
    print("Add distributed items:")
    item_code = input("Enter the item code: ")
    
    if not code_exists(item_code, "item", get_files_path()["ppe"], "PPE"):
        return
    
    quantity = input("Enter the quantity: ")
    if not quantity.isdigit():
        print("Invalid quantity. Please try again.")
        return
    
    quantity = int(quantity)
    if not enough_stock(item_code, quantity):
        return
    
    hospital_code = input("Enter the hospital code: ")
    if not code_exists(hospital_code, "hospital", get_files_path()["hospitals"], "Hospitals"):
        return
    
    update_item_stock(item_code, quantity, "distributed")
    record_transaction(item_code, quantity, "distributed", hospital_code, user_id)
    print("Item distribution completed successfully.")

# Function to check if the item supplier code match the item supplier code
def check_item_supplier_code(item_code, supplier_code):
    with open(get_files_path()["ppe"], "r") as file:
        for line in file:
            item_data = line.strip().split("|")
            if item_data[0] == item_code:
                if item_data[2] != supplier_code:
                    print("Item supplier code does not match the inputted supplier code.")
                    return False
    return True

# Function to check if the item code/supplier/hospital exists in file
def code_exists(code, code_type, file_path, file_name):
    if not check_file_exists(file_path, file_name):
        return False
    
    if code_type not in ["supplier", "hospital", "item"]:
        print("Invalid code type.")
        return False        

    with open(file_path, "r") as file:
        for line in file:
            item_data = line.strip().split("|")
            if item_data[0] == code:
                print(f"{code_type.capitalize()} code found.")
                return True
    print(f"{code_type.capitalize()} code not found.")
    return False  

    
# Function to check if there is enough stock for distribution
def enough_stock(item_code, quantity):
    ppe_file_path = get_files_path()["ppe"]
    if not check_file_exists(ppe_file_path, "PPE"):
        return False
    
    with open(ppe_file_path, "r") as file:
        for line in file:
            item_data = line.strip().split("|")
            if item_data[0] == item_code:
                print(f"Current stock: {item_data[3]} boxes")
                if int(item_data[3]) >= quantity:
                    print("Enough stock for distribution.")
                    return True 
                else:
                    print("Not enough stock for distribution.")
                    return False  
                
# Function to update item stock in the PPE inventory
def update_item_stock(item_code, quantity, operation_type):
    ppe_file_path = get_files_path()["ppe"]
    if not check_file_exists(ppe_file_path, "PPE"):
        return

    updated_ppe_data = []
    with open(ppe_file_path, "r") as file:
        for line in file:
            item_data = line.strip().split("|")
            if item_data[0] == item_code:
                if operation_type == "received":
                    item_data[3] = str(int(item_data[3]) + quantity)
                elif operation_type == "distributed":
                    item_data[3] = str(int(item_data[3]) - quantity)
                else:
                    print("Invalid operation type.")
                    return
                updated_ppe_data.append("|".join(item_data) + "\n")
            else:
                updated_ppe_data.append(line)
        
    with open(ppe_file_path, "w") as file:
        file.writelines(updated_ppe_data)
    print("\nItem stock updated successfully.")

# Function to record a transaction in the transactions file
def record_transaction(item_code, quantity, operation_type, code, user_id):
    transactions_file_path = get_files_path()["transactions"]
    if not check_file_exists(transactions_file_path, "Transactions"):
        return
    
    date_time = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    transaction = f"{date_time}|{item_code}|{quantity}|{operation_type}|{code}|{user_id}\n"
    with open(transactions_file_path, "a") as file:
        file.write(transaction)
    print("Transaction recorded successfully.")
    
# Function to view total quantity of items in inventory
def view_total_quantity():
    ppe_file_path = get_files_path()["ppe"]

    if not check_file_exists(ppe_file_path, "PPE"):
        return

    total_items = 0
    total_quantity = 0

    item_quantities = {}
    with open(ppe_file_path, "r") as file:
        for line in file:
            item_data = line.strip().split("|")
            item_code = item_data[0]
            quantity = int(item_data[3]) 
            total_quantity = total_quantity + quantity
            
            if item_code in item_quantities:
                item_quantities[item_code] += quantity
            else:
                item_quantities[item_code] = quantity
        total_items = len(item_quantities.items())        
        
    sorted_item_quantities = sorted(item_quantities.items(), key=lambda x: x[0])

    print("\nTotal Available Quantity of Items (Sorted by Item Code):")
    print("Total items in inventory: ", len(sorted_item_quantities))
    for item_code, quantity in sorted_item_quantities:
        print(f"Item Code: {item_code}, Total Quantity: {quantity} boxes")
    print (f"\nTotal items in inventory: {total_items}, Total Quantity: {total_quantity} boxes")
    
# Function to view low stock items under 25 boxes        
def view_low_stock_items():
    low_stock_threshold = 25 
    ppe_file_path = get_files_path()["ppe"]
    if not check_file_exists(ppe_file_path, "PPE"):
        return
    
    total_items = 0
    total_quantity = 0
    
    low_stock_items = {} 
    with open(ppe_file_path, "r") as file:
        for line in file:
            item_data = line.strip().split("|")
            item_code = item_data[0]
            stock_quantity = int(item_data[3])

            if stock_quantity < low_stock_threshold:
                total_items += 1
                if item_code in low_stock_items:
                    low_stock_items[item_code] += stock_quantity
                else:
                    low_stock_items[item_code] = stock_quantity

    if low_stock_items:
        print("Items with low stock quantity (less than 25 boxes):")
        print("Total items: ", len(low_stock_items.items()))
        for item_code, quantity in low_stock_items.items():
            if quantity < low_stock_threshold:
                total_quantity += quantity
                print(f"Item Code: {item_code}, Total Quantity: {quantity} boxes")
        
        print(f"\nTotal items under 25 boxes: {total_items}, Total Quantity: {total_quantity} boxes")
    else:
        print("No items found with low stock quantity.")

# Function to track item quantity
def track_item_quantity():
    item_code = input("Enter the item code you want to track: ")
    ppe_file_path = get_files_path()["ppe"]
    
    if not check_file_exists(ppe_file_path, "PPE"):
        return

    found_item = False

    with open(ppe_file_path, "r") as file:
        for line in file:
            item_data = line.strip().split("|")
            if item_data[0] == item_code:
                found_item = True
                item_name = item_data[1]
                stock_quantity = int(item_data[3]) 
                print(f"Item Code: {item_code}")
                print(f"Item Name: {item_name}")
                print(f"Total Quantity: {stock_quantity} boxes")
                break
            
    if not found_item:
        print(f"Item code {item_code} not found in the inventory.")
 
# Function to check if the date is valid in the format DD/MM/YYYY HH:MM:SS or DD/MM/YYYY   
def is_valid_date(date_str):
    try:
        date = datetime.strptime(date_str, "%d/%m/%Y %H:%M:%S")
        return True, date
    except ValueError:
        try:
            date = datetime.strptime(date_str, "%d/%m/%Y")
            return True, date
        except ValueError:
            return False, None

# Function to track item transactions
def track_item_transactions():
    start_date_str = input("Enter the start date (DD/MM/YYYY HH:MM:SS) or (DD/MM/YYYY): ")
    start_date_valid, start_date = is_valid_date(start_date_str)
    if not start_date_valid:
        print("Invalid date format. Please use the format DD/MM/YYYY HH:MM:SS or DD/MM/YYYY.")
        return
    
    end_date_str = input("Enter the end date (DD/MM/YYYY HH:MM:SS): ")
    end_date_valid, end_date = is_valid_date(end_date_str)
    if not end_date_valid:
        print("Invalid date format. Please use the format DD/MM/YYYY HH:MM:SS.")
        return

    if start_date >= end_date:
        print("End date must be later than the start date.")
        return

    transactions_file_path = get_files_path()["transactions"]
    if not check_file_exists(transactions_file_path, "Transactions"):
        return

    item_transactions = []
    with open(transactions_file_path, "r") as file:
        for line in file:
            transaction_data = line.strip().split("|")
            transaction_date_str = transaction_data[0]
            transaction_type = transaction_data[3]

            transaction_date = datetime.strptime(transaction_date_str, "%d/%m/%Y %H:%M:%S")
            if start_date <= transaction_date <= end_date and transaction_type == "received":
                item_transactions.append(line.strip())

    if item_transactions:
        print(f"\nItem transactions between {start_date_str} and {end_date_str}:")
        print("Total transactions: ", len(item_transactions))
        for transaction in item_transactions:
            print(transaction)
    else:
        print(f"No received item transactions found between {start_date_str} and {end_date_str}.")

# Function to search for item distribution details from transactions file "Hospital"  
def search_item_distribution():
    item_code = input("Enter the item code to search for distribution details: ")

    transactions = load_transactions()
    filtered_transactions = filter_transactions_by_item(transactions, item_code, "distributed")

    display_transaction_details(filtered_transactions, item_code, "distributions")

# Function to search for item receipt details from transactions file "Supplier"
def search_item_receipt():
    item_code = input("Enter the item code to search for receipt details: ")

    transactions = load_transactions()
    filtered_transactions = filter_transactions_by_item(transactions, item_code, "received")

    display_transaction_details(filtered_transactions, item_code, "receipts")

# Function to load transactions from the transactions file
def load_transactions():
    transactions = []
    transactions_file_path = get_files_path()["transactions"]

    if not check_file_exists(transactions_file_path, "Transactions"):
        return transactions

    with open(transactions_file_path, "r") as file:
        for line in file:
            transaction_data = line.strip().split("|")
            transactions.append(transaction_data)

    return transactions

# Function to filter transactions by item code and transaction type
def filter_transactions_by_item(transactions, item_code, transaction_type):
    filtered_transactions = []
    for transaction in transactions:
        if transaction[1] == item_code and transaction[3] == transaction_type:
            filtered_transactions.append(transaction)

    return filtered_transactions

# Function to display transaction details
def display_transaction_details(transactions, item_code, transaction_type):
    if not transactions:
        print(f"No {transaction_type} details found for item code: {item_code}.")
    else:
        print(f"{transaction_type.capitalize()} details for item code: {item_code}:")
        
        transaction_summary = {} 
        for transaction in transactions:
            date = transaction[0]
            hospital_supplier_code = transaction[4]
            quantity = int(transaction[2])

            if hospital_supplier_code in transaction_summary:
                transaction_summary[hospital_supplier_code]['quantity'] += quantity
                transaction_summary[hospital_supplier_code]['dates'].append(date)
            else:
                transaction_summary[hospital_supplier_code] = {'quantity': quantity, 'dates': [date]}

        for hospital_supplier_code, summary in transaction_summary.items():
            total_quantity = summary['quantity']
            dates = sorted(summary['dates'])  
            date_count = len(dates)
            date_range = f"{dates[0]} to {dates[-1]}" if date_count > 1 else dates[0]
            
            if transaction_type == "receipts":
                print(f"Supplier Code: {hospital_supplier_code}, Quantity Received: {total_quantity}, Date Range: {date_range} (Occurrences: {date_count})")
            elif transaction_type == "distributions":
                print(f"Hospital Code: {hospital_supplier_code}, Quantity Distributed: {total_quantity}, Date Range: {date_range} (Occurrences: {date_count})")
    
# Function to check if the users file exists and contains at least one admin user
def check_admin_existence():
    user_file_path = get_files_path()["users"]
    if not os.path.exists(user_file_path):
        with open(user_file_path, "w") as file:
            pass  # Create an empty file

    with open(user_file_path, "r") as file:
        for line in file:
            user_data = line.strip().split("|")
            if len(user_data) >= 4 and user_data[3].strip() == "admin":
                return True

    return False

# Function to create a new admin user
def create_admin_user():
    user_id = input("Enter admin user ID: ")
    name = input("Enter admin name: ")
    password = input("Enter admin password: ")
    
    # Write the admin user to users.txt
    user_file_path = get_files_path()["users"]
    with open(user_file_path, "a") as file:
        file.write(f"{user_id}|{name}|{password}|admin\n")

# Function to handle user login
def login():
    if not check_admin_existence():
        print("No admin user found. Please create an admin account.")
        create_admin_user()

    for _ in range(3):
        print("\nLogin attempts remaining:", 3 - _)
        print("Login:")
        user_id = input("Enter user ID: ")
        password = input("Enter password: ")

        users_file_path = get_files_path()["users"]
        with open(users_file_path, "r") as file:
            for line in file:
                user_data = line.strip().split("|")
                if len(user_data) >= 4 and user_data[0].strip() == user_id and user_data[2].strip() == password:
                    user_type = user_data[3].strip()
                    if user_type == "admin":
                        return "admin" , user_id
                    elif user_type == "staff":
                        return "staff" , user_id
        
        print("Login failed. Please retry.")

    print("Maximum login attempts reached. Exiting.")
    exit()


# Define menu options and associated functions
def get_menu_structure():
    return {
        "admin": {
            "User Management": {
                "Add new users": add_user,
                "Modify user details": modify_user,
                "Search for users": search_user,
                "Delete users": delete_user,
            },
            "Item Inventory Update": {
                "Add received items": add_received_inventory,
                "Add distributed items": add_distributed_inventory,
            },
            "Item Inventory Tracking": {
                "Total available quantity": view_total_quantity,
                "Low stock items": view_low_stock_items,
                "Track item quantity": track_item_quantity,
                "Track item transactions": track_item_transactions,
            },
            "Search Functionalities": {
                "Search item distribution": search_item_distribution,
                "Search item receipt": search_item_receipt,
            },
            "Exit Program": exit,
        },
        "staff": {
            "Item Inventory Update": {
                "Add received items": add_received_inventory,
                "Add distributed items": add_distributed_inventory,
            },
            "Item Inventory Tracking": {
                "Total available quantity": view_total_quantity,
                "Low stock items": view_low_stock_items,
                "Track item quantity": track_item_quantity,
                "Track item transactions": track_item_transactions,
            },
            "Search Functionalities": {
                "Search item distribution": search_item_distribution,
                "Search item receipt": search_item_receipt,
            },
            "Exit Program": exit,
        },
    }

# Function to render the menu based on user type
def render_menu(user_type, menu_structure, user_id):
    while True:
        print("\nMain Menu:")
        menu_options = menu_structure.get(user_type, {})
        
        for i, option in enumerate(menu_options, start=1):
            print(f"{i}. {option}")
        
        choice = input("Enter your choice: ")

        if choice.isdigit():
            choice = int(choice)
            if 1 <= choice <= len(menu_options):
                selected_option = list(menu_options.keys())[choice - 1]
                print(f"You selected: {selected_option}")
                
                selected_function = menu_options[selected_option]
                if callable(selected_function):
                    selected_function()
                else:
                    render_submenu(selected_option, selected_function, user_id)
            else:
                print("Invalid choice. Please enter a valid menu option number.")
        else:
            print("Invalid input. Please enter a valid menu option number.")

# Function to render a submenu
def render_submenu(parent_option, submenu, user_id):
    while True:
        print(f"\n{parent_option} Submenu:")
        for i, option in enumerate(submenu, start=1):
            print(f"{i}. {option}")
        
        choice = input("Enter your choice (or 'b' to go back): ")

        if choice.isdigit():
            choice = int(choice)
            if 1 <= choice <= len(submenu):
                selected_option = list(submenu.keys())[choice - 1]
                print(f"You selected: {selected_option}\n")
                
                selected_function = submenu[selected_option]
                if callable(selected_function):
                    # For add received items and add distributed items, pass the user ID to the function 
                    # So it can be recorded in the transactions file
                    if selected_option == "Add received items" or selected_option == "Add distributed items":
                        selected_function(user_id)
                    else:
                        selected_function()
                else:
                    print("Invalid submenu option. Please try again.")
            else:
                print("Invalid choice. Please enter a valid submenu option number.")
        elif choice.lower() == "b":
            break
        else:
            print("Invalid input. Please enter a valid submenu option number or 'b' to go back.")

# Main program
if __name__ == "__main__":
    initialize_data()
    user_type, user_id = login()
    menu_structure = get_menu_structure()
    if user_type == "admin":
        print("Welcome, Admin!")
        render_menu("admin", menu_structure, user_id)
    elif user_type == "staff":
        print("Welcome, Staff!")
        render_menu("staff", menu_structure, user_id)